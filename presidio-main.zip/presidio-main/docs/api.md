# Presidio API

Api reference for Presidio's main python modules

- [Presidio analyzer Python API reference](api/analyzer_python.md)
- [Presidio anonymizer Python API reference](api/anonymizer_python.md)
- [Presidio image redactor Python API reference](api/image_redactor_python.md)
