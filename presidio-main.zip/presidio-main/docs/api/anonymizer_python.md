# Presidio Anonymizer API Reference

::: presidio_anonymizer
    handler: python
    options:
      docstring_style: sphinx
