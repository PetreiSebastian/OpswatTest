# Presidio Analyzer API Reference

::: presidio_analyzer
    handler: python
    options:
      docstring_style: sphinx
