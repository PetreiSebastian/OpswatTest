# Presidio Image Redactor API Reference

::: presidio_image_redactor
    handler: python
    options:
      docstring_style: sphinx
