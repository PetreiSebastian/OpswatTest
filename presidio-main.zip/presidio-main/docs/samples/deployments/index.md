# Example deployments

- [Azure App Service](app-service/index.md)
- [Kubernetes](k8s/index.md)
- [Spark/Azure Databricks](spark/index.md)
- [Azure Data Factory](data-factory/index.md)
