"""A Python CLI for analyzing PII Entities with Microsoft Presidio framework."""


APP_NAME = "presidio_cli"
APP_VERSION = "0.0.8"
APP_DESCRIPTION = __doc__
SHELL_NAME = "presidio"

__version__ = APP_VERSION
